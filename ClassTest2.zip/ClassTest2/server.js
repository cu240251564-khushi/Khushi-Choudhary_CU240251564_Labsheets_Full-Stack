const express = require('express');
const cors = require('cors');

const app = express();
app.use(express.json());

// Q7: CORS Configuration for Local Dev
// Enables Cross-Origin Resource Sharing for React frontend running at localhost:3000
app.use(cors({ origin: 'http://localhost:3000' }));

// In-memory data store for Books (Q4)
let books = [
  { id: 1, title: 'The Great Gatsby', author: 'F. Scott Fitzgerald' },
  { id: 2, title: 'To Kill a Mockingbird', author: 'Harper Lee' }
];

// Q3: Custom Middleware 'requireAuth'
const requireAuth = (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey || apiKey !== 'secret123') {
    return res.status(401).json({ error: '401 Unauthorized: Invalid or missing API Key' });
  }
  next();
};

// Q4 & Q3: Routing & REST API Endpoints
// GET /api/books -> List all books (Public)
app.get('/api/books', (req, res) => {
  res.status(200).json(books);
});

// POST /api/books -> Create a new book (Protected by requireAuth)
app.post('/api/books', requireAuth, (req, res) => {
  const { title, author } = req.body;
  if (!title || !author) {
    return res.status(400).json({ error: 'Title and author are required' });
  }

  const newBook = {
    id: books.length > 0 ? books[books.length - 1].id + 1 : 1,
    title,
    author
  };

  books.push(newBook);
  res.status(201).json(newBook);
});

// DELETE /api/books/:id -> Delete a book (404 if missing)
app.delete('/api/books/:id', (req, res) => {
  const bookId = parseInt(req.params.id);
  const index = books.findIndex(b => b.id === bookId);

  if (index === -1) {
    return res.status(404).json({ error: 'Book not found' });
  }

  const deletedBook = books.splice(index, 1);
  res.status(200).json({ message: 'Book deleted successfully', book: deletedBook[0] });
});


// Q5: Fixed GET /api/books/:id Error Handling
/*
  BUG IDENTIFICATION:
  The original code `res.json(book.title)` attempts to access `.title` on `undefined` 
  when a book is not found, causing a runtime `TypeError: Cannot read properties of undefined` 
  and crashing/hanging the server response.
*/
app.get('/api/books/:id', (req, res) => {
  const bookId = parseInt(req.params.id);
  const book = books.find(b => b.id === bookId);

  if (!book) {
    return res.status(404).json({ error: 'Book not found' });
  }

  res.status(200).json(book);
});

// Start Server
const PORT = 5000;
app.listen(PORT, () => {
  console.log(`Express server running on http://localhost:${PORT}`);
});