// A
// D
// C
// B

// Justification:
// Synchronous code executes first sequentially on the call stack (A, then D). 
// Promise.resolve().then() is queued in the Microtask queue, which executes immediately after the current synchronous stack completes (C), 
// while setTimeout is queued in the Timers phase (macrotask queue), executing last (B)


const { add, subtract } = require('./calc');
console.log('Result of add(4, 5):', add(4, 5));