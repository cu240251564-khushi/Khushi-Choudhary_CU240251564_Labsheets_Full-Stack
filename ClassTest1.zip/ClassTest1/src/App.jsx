import React from 'react';
import Counter from './components/Counter';
import TodoList from './components/TodoList';
import LoginToggle from './components/LoginToggle';
import LiveSearch from './components/LiveSearch';
import Stopwatch from './components/Stopwatch';
import './App.css';

function App() {
  return (
    <div className="app-container">
      <header className="app-header">
        <h1>React Assignment Solutions</h1>
        <p>5 Interactive Components</p>
      </header>

      <main className="grid-container">
        <Counter />
        <TodoList />
        <LoginToggle />
        <LiveSearch />
        <Stopwatch />
      </main>
    </div>
  );
}

export default App;