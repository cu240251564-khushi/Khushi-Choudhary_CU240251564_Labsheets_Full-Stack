import React, { useState } from 'react';

const NAMES_LIST = [
  "Alice Johnson",
  "Bob Smith",
  "Charlie Brown",
  "Diana Prince",
  "Edward Stark",
  "Fiona Gallagher",
  "George Clark",
  "Hannah Abbott",
  "Ian Malcolm",
  "Julia Roberts"
];

export default function LiveSearch() {
  const [query, setQuery] = useState('');

  const filteredNames = NAMES_LIST.filter(name =>
    name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="card">
      <h2>Q4: Live Search Filter</h2>
      <input
        type="text"
        placeholder="Search names..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="search-input"
      />

      <ul className="search-list">
        {filteredNames.length > 0 ? (
          filteredNames.map((name, index) => (
            <li key={index} className="search-item">{name}</li>
          ))
        ) : (
          <p className="no-results">No results found</p>
        )}
      </ul>
    </div>
  );
}