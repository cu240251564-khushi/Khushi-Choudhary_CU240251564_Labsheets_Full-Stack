import React, { useState } from 'react';

export default function TodoList() {
  const [todos, setTodos] = useState([]);
  const [input, setInput] = useState('');

  const addTodo = (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    setTodos([...todos, { id: Date.now(), text: input.trim() }]);
    setInput('');
  };

  const deleteTodo = (id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  };

  return (
    <div className="card">
      <h2>Q2: Todo List</h2>
      <form onSubmit={addTodo} className="input-group">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Enter a task..."
        />
        <button type="submit" className="btn btn-primary">Add</button>
      </form>

      <ul className="todo-list">
        {todos.length === 0 ? (
          <p className="empty-msg">No tasks added yet.</p>
        ) : (
          todos.map((todo) => (
            <li key={todo.id} className="todo-item">
              <span>{todo.text}</span>
              <button 
                onClick={() => deleteTodo(todo.id)} 
                className="btn btn-delete"
              >
                Delete
              </button>
            </li>
          ))
        )}
      </ul>
    </div>
  );
}