import React, { useState, useEffect } from 'react';

export default function Stopwatch() {
  const [time, setTime] = useState(0); // in deciseconds (1/10th of a sec)
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    let interval = null;
    if (isRunning) {
      interval = setInterval(() => {
        setTime(prevTime => prevTime + 1);
      }, 100);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isRunning]);

  const handleStart = () => setIsRunning(true);
  const handlePause = () => setIsRunning(false);
  const handleReset = () => {
    setIsRunning(false);
    setTime(0);
  };

  const seconds = (Math.floor(time / 10) % 60).toString().padStart(2, '0');
  const minutes = Math.floor(time / 600).toString().padStart(2, '0');
  const deciSeconds = (time % 10).toString();

  return (
    <div className="card">
      <h2>Q5: Stopwatch</h2>
      <div className="stopwatch-display">
        {minutes}:{seconds}.<span className="deci">{deciSeconds}</span>
      </div>
      <div className="button-group">
        {!isRunning ? (
          <button onClick={handleStart} className="btn btn-primary">Start</button>
        ) : (
          <button onClick={handlePause} className="btn btn-warning">Pause</button>
        )}
        <button onClick={handleReset} className="btn btn-secondary">Reset</button>
      </div>
    </div>
  );
}