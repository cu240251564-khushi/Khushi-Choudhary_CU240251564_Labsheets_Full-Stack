import React, { useState } from 'react';

export default function LoginToggle() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  return (
    <div className="card">
      <h2>Q3: Login Toggle</h2>
      {isLoggedIn ? (
        <div className="login-box logged-in">
          <h3>Welcome back, User! 👋</h3>
          <p>You are successfully logged in.</p>
          <button onClick={() => setIsLoggedIn(false)} className="btn btn-danger">
            Logout
          </button>
        </div>
      ) : (
        <div className="login-box logged-out">
          <p>Please log in to continue.</p>
          <button onClick={() => setIsLoggedIn(true)} className="btn btn-primary">
            Login
          </button>
        </div>
      )}
    </div>
  );
}