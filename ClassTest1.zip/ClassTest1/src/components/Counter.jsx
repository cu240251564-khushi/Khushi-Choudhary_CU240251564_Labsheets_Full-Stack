import React, { useState } from 'react';

export default function Counter() {
  const [count, setCount] = useState(0);

  const increment = () => setCount(prev => prev + 1);
  const decrement = () => setCount(prev => Math.max(0, prev - 1));
  const reset = () => setCount(0);

  return (
    <div className="card">
      <h2>Q1: Counter</h2>
      <div className="count-display">{count}</div>
      <div className="button-group">
        <button onClick={decrement} disabled={count === 0} className="btn btn-danger">
          Decrement
        </button>
        <button onClick={reset} className="btn btn-secondary">
          Reset
        </button>
        <button onClick={increment} className="btn btn-primary">
          Increment
        </button>
      </div>
      {count === 0 && <p className="hint">Decrement disabled at count 0</p>}
    </div>
  );
}